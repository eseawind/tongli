/*
 * BEAN类  微信用户分组信息
 *
 * VERSION  DATE        BY              REASON
 * -------- ----------- --------------- ------------------------------------------
 * 1.00     2014.02.26  wangzi           程序发布
 * -------- ----------- --------------- ------------------------------------------
 * Copyright 2014 车主管家  System. - All Rights Reserved.
 *
 */
package cn.com.softvan.bean.wechat;

import cn.com.softvan.bean.BaseBean;

/**
 * <p> 微信用户分组信息 <p>
 * @author wangzi
 *
 */
public class TcWxUserGroupsBean extends BaseBean {
    /**
	 * 
	 */
	private static final long serialVersionUID = -177257490905926333L;

}