/*
 * 数据传输对象接口
 *
 * VERSION  DATE        BY              REASON
 * -------- ----------- --------------- ------------------------------------------
 * 1.00     2012.04.17  wuxiaogang       程序・发布  
 * -------- ----------- --------------- ------------------------------------------
 * Copyright 2014 车主管家  System. - All Rights Reserved.
 *
 */
package cn.com.softvan.dao.entity;

/**
 * <p>数据传输对象接口</p>
 * @author wuxiaogang
 *
 */
public interface IEntity {

}
